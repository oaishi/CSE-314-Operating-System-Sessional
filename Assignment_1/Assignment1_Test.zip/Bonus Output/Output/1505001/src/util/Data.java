/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import java.io.Serializable;

/**
 *
 * @author uesr
 */
public class Data  implements Serializable {
    
     public String info;
     
     public Data(String information){
         info=information;
     }
    
}
