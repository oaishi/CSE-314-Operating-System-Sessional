#include "types.h"
#include "user.h"

int
main(int argc , char *argv[])
{
	//int i;
	//i = faria_huq();
	//mine_print(i);
	printf(1, "%d\n", faria_huq());
	exit();
}
